import './App.css';
import './scrollBar.css'
import Labyrinth from './Components/Labyrinth';

function App() {
  return (
    <div className="App">
      {/* <Login/> */}
      <Labyrinth/>
    </div>
  );
}

export default App;
