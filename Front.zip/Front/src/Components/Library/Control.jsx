import { motion } from 'framer-motion'
import React from 'react'

export const Controls = () => {
    return (
        <motion.div className='library-control'>
            
        </motion.div>
    )
}
